package ru.megacraft;

import java.util.List;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

/** Автоплавка и магнит: правим готовый список дропа (блоки и мобы). */
public final class DropHooks {
    private DropHooks() {
    }

    public static void init() {
        LootTableEvents.MODIFY_DROPS.register((holder, context, drops) -> handle(context, drops));
    }

    private static void handle(LootContext context, List<ItemStack> drops) {
        if (drops.isEmpty()) {
            return;
        }
        ServerPlayer player = null;
        ItemStack tool = ItemStack.EMPTY;

        if (context.hasParameter(LootContextParams.BLOCK_STATE) && context.hasParameter(LootContextParams.TOOL)) {
            Entity e = context.getOptionalParameter(LootContextParams.THIS_ENTITY);
            if (e instanceof ServerPlayer sp) {
                player = sp;
                tool = context.getParameter(LootContextParams.TOOL);
            }
        } else if (context.hasParameter(LootContextParams.DAMAGE_SOURCE)
                && context.hasParameter(LootContextParams.ATTACKING_ENTITY)) {
            Entity a = context.getOptionalParameter(LootContextParams.ATTACKING_ENTITY);
            if (a instanceof ServerPlayer sp) {
                player = sp;
                tool = sp.getMainHandItem();
            }
        }
        if (player == null || tool == null || tool.isEmpty()) {
            return;
        }

        if (ModEnchants.level(tool, ModEnchants.AUTOSMELT) > 0) {
            for (int i = 0; i < drops.size(); i++) {
                drops.set(i, Smelt.apply(drops.get(i)));
            }
        }

        if (ModEnchants.level(tool, ModEnchants.MAGNET) > 0) {
            for (ItemStack stack : drops) {
                if (stack.isEmpty()) {
                    continue;
                }
                if (!player.getInventory().add(stack)) {
                    player.drop(stack, false);
                }
            }
            drops.clear();
        }
    }
}

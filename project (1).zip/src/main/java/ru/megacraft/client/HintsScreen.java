package ru.megacraft.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import ru.megacraft.ModItems;

/** Меню подсказок: чары, предметы, структуры и рецепт запретной кирки. */
public class HintsScreen extends Screen {
    private static final int PAGES = 3;
    private static final int LINES_PER_PAGE = 5;
    private final Screen parent;
    private int page = 0;

    public HintsScreen(Screen parent) {
        super(Component.translatable("screen.megacraft.hints"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height - 28;
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            page = (page + PAGES - 1) % PAGES;
        }).bounds(cx - 110, y, 30, 20).build());
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> this.minecraft.setScreen(parent))
                .bounds(cx - 40, y, 80, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            page = (page + 1) % PAGES;
        }).bounds(cx + 80, y, 30, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, this.title, this.width / 2, 10, 0xFFFFFFFF);
        g.drawCenteredString(this.font,
                Component.translatable("hint.megacraft.p" + (page + 1) + ".title"), this.width / 2, 24, 0xFFFFD34D);

        int textWidth = Math.min(this.width - 40, 320);
        int x = (this.width - textWidth) / 2;
        int y = 40;
        for (int i = 1; i <= LINES_PER_PAGE; i++) {
            Component c = Component.translatable("hint.megacraft.p" + (page + 1) + ".l" + i);
            for (FormattedCharSequence seq : this.font.split(c, textWidth)) {
                g.drawString(this.font, seq, x, y, 0xFFFFFFFF);
                y += 10;
            }
            y += 3;
        }

        if (page == 1) {
            // Рецепт запретной кирки
            ItemStack[] grid = {
                    new ItemStack(Items.NETHERITE_BLOCK), new ItemStack(Items.NETHER_STAR), new ItemStack(Items.NETHERITE_BLOCK),
                    ItemStack.EMPTY, new ItemStack(Items.BLAZE_ROD), ItemStack.EMPTY,
                    ItemStack.EMPTY, new ItemStack(Items.BLAZE_ROD), ItemStack.EMPTY};
            int gx = this.width / 2 - 50;
            int gy = Math.min(y + 4, this.height - 28 - 60);
            for (int i = 0; i < 9; i++) {
                int sx = gx + (i % 3) * 18;
                int sy = gy + (i / 3) * 18;
                g.fill(sx, sy, sx + 18, sy + 18, 0xFF555555);
                g.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF8B8B8B);
                if (!grid[i].isEmpty()) {
                    g.renderItem(grid[i], sx + 1, sy + 1);
                }
            }
            g.drawString(this.font, "=>", gx + 62, gy + 22, 0xFFFFFFFF);
            g.renderItem(new ItemStack(ModItems.FORBIDDEN_PICKAXE), gx + 84, gy + 19);
        }
    }
}

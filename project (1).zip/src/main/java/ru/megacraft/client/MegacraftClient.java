package ru.megacraft.client;

import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.ShulkerBoxBlock;

public class MegacraftClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Кнопка «?» в инвентаре -> меню подсказок.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof InventoryScreen) {
                int x = (scaledWidth - 176) / 2 + 176 + 4;
                int y = (scaledHeight - 166) / 2;
                Button button = Button.builder(Component.literal("?"), b -> client.setScreen(new HintsScreen(screen)))
                        .bounds(x, y, 20, 20)
                        .build();
                Screens.getButtons(screen).add(button);
            }
        });

        // Полное содержимое шалкера при наведении.
        ItemTooltipCallback.EVENT.register((stack, context, flag, lines) -> {
            if (!(stack.getItem() instanceof BlockItem bi) || !(bi.getBlock() instanceof ShulkerBoxBlock)) {
                return;
            }
            ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
            if (contents == null) {
                return;
            }
            Map<Item, Integer> totals = new LinkedHashMap<>();
            for (ItemStack s : contents.nonEmptyItems()) {
                totals.merge(s.getItem(), s.getCount(), Integer::sum);
            }
            if (totals.isEmpty()) {
                return;
            }
            lines.removeIf(c -> c.getContents() instanceof TranslatableContents tc && tc.getKey().startsWith("container.shulkerBox"));
            lines.add(Component.translatable("tooltip.megacraft.shulker_header").withStyle(ChatFormatting.GOLD));
            int shown = 0;
            for (Map.Entry<Item, Integer> e : totals.entrySet()) {
                if (shown >= 27) {
                    break;
                }
                lines.add(Component.translatable("tooltip.megacraft.shulker_line",
                        e.getKey().getDefaultInstance().getHoverName(), e.getValue()).withStyle(ChatFormatting.GRAY));
                shown++;
            }
        });
    }
}

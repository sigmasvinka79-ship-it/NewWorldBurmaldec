package ru.megacraft;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Золотая кирка с переливающимся иероглифическим названием. */
public class ForbiddenPickaxeItem extends Item {
    private static final String NAME = "破禁神镐";

    public ForbiddenPickaxeItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public Component getName(ItemStack stack) {
        long t = System.currentTimeMillis();
        MutableComponent out = Component.empty();
        for (int i = 0; i < NAME.length(); i++) {
            float hue = ((t / 10L + i * 90L) % 1000L) / 1000.0f;
            int rgb = hsvToRgb(hue, 0.55f, 1.0f);
            out.append(Component.literal(String.valueOf(NAME.charAt(i)))
                    .withStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb)).withBold(true)));
        }
        return out;
    }

    private static int hsvToRgb(float h, float s, float v) {
        float r;
        float g;
        float b;
        int i = (int) Math.floor(h * 6.0f);
        float f = h * 6.0f - i;
        float p = v * (1.0f - s);
        float q = v * (1.0f - f * s);
        float tt = v * (1.0f - (1.0f - f) * s);
        switch (((i % 6) + 6) % 6) {
            case 0 -> { r = v; g = tt; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = tt; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = tt; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}

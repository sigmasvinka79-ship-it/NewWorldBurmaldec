package ru.megacraft;

import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;

public final class MegaTags {
    public static final TagKey<Block> VEIN_MINEABLE = TagKey.create(Registries.BLOCK, MegacraftMod.id("vein_mineable"));
    public static final TagKey<Block> FORBIDDEN = TagKey.create(Registries.BLOCK, MegacraftMod.id("forbidden"));

    private MegaTags() {
    }
}

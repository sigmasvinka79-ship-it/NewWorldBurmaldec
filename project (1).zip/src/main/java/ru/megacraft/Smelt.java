package ru.megacraft;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Быстрая «переплавка» дропа (без обращения к рецептам: быстро и без лагов). */
public final class Smelt {
    private static final Map<Item, Item> MAP = new HashMap<>();

    static {
        MAP.put(Items.RAW_IRON, Items.IRON_INGOT);
        MAP.put(Items.RAW_GOLD, Items.GOLD_INGOT);
        MAP.put(Items.RAW_COPPER, Items.COPPER_INGOT);
        MAP.put(Items.IRON_ORE, Items.IRON_INGOT);
        MAP.put(Items.DEEPSLATE_IRON_ORE, Items.IRON_INGOT);
        MAP.put(Items.GOLD_ORE, Items.GOLD_INGOT);
        MAP.put(Items.DEEPSLATE_GOLD_ORE, Items.GOLD_INGOT);
        MAP.put(Items.NETHER_GOLD_ORE, Items.GOLD_INGOT);
        MAP.put(Items.COPPER_ORE, Items.COPPER_INGOT);
        MAP.put(Items.DEEPSLATE_COPPER_ORE, Items.COPPER_INGOT);
        MAP.put(Items.ANCIENT_DEBRIS, Items.NETHERITE_SCRAP);
        MAP.put(Items.COBBLESTONE, Items.STONE);
        MAP.put(Items.COBBLED_DEEPSLATE, Items.DEEPSLATE);
        MAP.put(Items.CLAY_BALL, Items.BRICK);
        MAP.put(Items.NETHERRACK, Items.NETHER_BRICK);
        MAP.put(Items.STONE_BRICKS, Items.CRACKED_STONE_BRICKS);
        MAP.put(Items.DEEPSLATE_BRICKS, Items.CRACKED_DEEPSLATE_BRICKS);
        MAP.put(Items.NETHER_BRICKS, Items.CRACKED_NETHER_BRICKS);
        MAP.put(Items.KELP, Items.DRIED_KELP);
        MAP.put(Items.CACTUS, Items.GREEN_DYE);
        MAP.put(Items.SEA_PICKLE, Items.LIME_DYE);
        MAP.put(Items.CHORUS_FRUIT, Items.POPPED_CHORUS_FRUIT);
        MAP.put(Items.WET_SPONGE, Items.SPONGE);
        MAP.put(Items.POTATO, Items.BAKED_POTATO);
        MAP.put(Items.BEEF, Items.COOKED_BEEF);
        MAP.put(Items.PORKCHOP, Items.COOKED_PORKCHOP);
        MAP.put(Items.MUTTON, Items.COOKED_MUTTON);
        MAP.put(Items.CHICKEN, Items.COOKED_CHICKEN);
        MAP.put(Items.RABBIT, Items.COOKED_RABBIT);
        MAP.put(Items.COD, Items.COOKED_COD);
        MAP.put(Items.SALMON, Items.COOKED_SALMON);
        MAP.put(Items.SAND, Items.GLASS);
        MAP.put(Items.RED_SAND, Items.GLASS);
    }

    private Smelt() {
    }

    public static ItemStack apply(ItemStack in) {
        Item out = MAP.get(in.getItem());
        if (out == null && in.is(ItemTags.LOGS_THAT_BURN)) {
            out = Items.CHARCOAL;
        }
        if (out == null) {
            return in;
        }
        return new ItemStack(out, in.getCount());
    }
}

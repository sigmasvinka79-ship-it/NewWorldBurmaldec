package ru.megacraft;

import java.util.List;
import java.util.function.Function;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.ItemLore;

public final class ModItems {
    public static Item FORBIDDEN_PICKAXE;
    public static Item ABYSS_BLADE;
    public static Item TITAN_PICKAXE;
    public static Item WORLD_AXE;

    private ModItems() {
    }

    private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, MegacraftMod.id(name));
        T item = factory.apply(props.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    private static Component lore(String key) {
        return Component.translatable(key).withStyle(Style.EMPTY.withItalic(false).withColor(ChatFormatting.GRAY));
    }

    public static void init() {
        FORBIDDEN_PICKAXE = register("forbidden_pickaxe", ForbiddenPickaxeItem::new,
                new Item.Properties()
                        .pickaxe(ToolMaterial.NETHERITE, 1.0F, -2.8F)
                        .rarity(Rarity.EPIC)
                        .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
                        .component(DataComponents.LORE, new ItemLore(List.of(
                                lore("item.megacraft.forbidden_pickaxe.lore1"),
                                lore("item.megacraft.forbidden_pickaxe.lore2")))));

        ABYSS_BLADE = register("abyss_blade", Item::new,
                new Item.Properties()
                        .sword(ToolMaterial.NETHERITE, 4.0F, -2.4F)
                        .rarity(Rarity.EPIC)
                        .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true));

        TITAN_PICKAXE = register("titan_pickaxe", Item::new,
                new Item.Properties()
                        .pickaxe(ToolMaterial.NETHERITE, 1.0F, -2.8F)
                        .rarity(Rarity.EPIC)
                        .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true));

        WORLD_AXE = register("world_axe", Item::new,
                new Item.Properties()
                        .axe(ToolMaterial.NETHERITE, 5.0F, -3.0F)
                        .rarity(Rarity.EPIC)
                        .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true));

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(group -> {
            group.accept(FORBIDDEN_PICKAXE);
            group.accept(TITAN_PICKAXE);
            group.accept(WORLD_AXE);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(group -> group.accept(ABYSS_BLADE));
    }
}

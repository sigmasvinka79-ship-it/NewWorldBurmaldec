package ru.megacraft;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

public final class ModEnchants {
    public static final ResourceKey<Enchantment> AUTOSMELT = key("autosmelt");
    public static final ResourceKey<Enchantment> MAGNET = key("magnet");
    public static final ResourceKey<Enchantment> BULLDOZER = key("bulldozer");
    public static final ResourceKey<Enchantment> VEIN = key("vein");

    private ModEnchants() {
    }

    private static ResourceKey<Enchantment> key(String name) {
        return ResourceKey.create(Registries.ENCHANTMENT, MegacraftMod.id(name));
    }

    /** Уровень зачарования на предмете (0, если нет). */
    public static int level(ItemStack stack, ResourceKey<Enchantment> key) {
        if (stack == null || stack.isEmpty()) {
            return 0;
        }
        ItemEnchantments ench = stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
        for (Holder<Enchantment> holder : ench.keySet()) {
            if (holder.is(key)) {
                return ench.getLevel(holder);
            }
        }
        return 0;
    }
}

package ru.megacraft;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class MegacraftMod implements ModInitializer {
    public static final String MOD_ID = "megacraft";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModItems.init();
        DropHooks.init();
        BreakHooks.init();
        ForbiddenHooks.init();
        LootHooks.init();
    }
}

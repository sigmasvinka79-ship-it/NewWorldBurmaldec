package ru.megacraft;

import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.resources.RegistryOps;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.ChatFormatting;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Запретная кирка: один раз ломает «запретный» блок (кроме бедрока). */
public final class ForbiddenHooks {
    private static final String USED_KEY = "megacraft_used";

    private ForbiddenHooks() {
    }

    public static void init() {
        // Ломаемые блоки (спавнер и т.п.): обычная добыча кирки.
        PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, be) -> {
            if (level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
                ItemStack tool = sp.getMainHandItem();
                if (tool.is(ModItems.FORBIDDEN_PICKAXE) && state.is(MegaTags.FORBIDDEN)) {
                    if (tryForbidden(sl, sp, pos, tool)) {
                        return false;
                    }
                }
            }
            return true;
        });

        // Неломаемые блоки: ПКМ киркой по блоку.
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (hand == InteractionHand.MAIN_HAND && level instanceof ServerLevel sl && player instanceof ServerPlayer sp) {
                ItemStack tool = sp.getMainHandItem();
                if (tool.is(ModItems.FORBIDDEN_PICKAXE)) {
                    BlockPos pos = hit.getBlockPos();
                    if (sl.getBlockState(pos).is(MegaTags.FORBIDDEN) && tryForbidden(sl, sp, pos, tool)) {
                        return InteractionResult.SUCCESS;
                    }
                }
            }
            return InteractionResult.PASS;
        });
    }

    private static boolean isUsed(ItemStack tool) {
        return tool.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().contains(USED_KEY);
    }

    private static boolean tryForbidden(ServerLevel level, ServerPlayer player, BlockPos pos, ItemStack tool) {
        BlockState st = level.getBlockState(pos);
        if (!st.is(MegaTags.FORBIDDEN)) {
            return false;
        }
        if (isUsed(tool)) {
            player.displayClientMessage(Component.translatable("message.megacraft.forbidden_used"), true);
            return false;
        }

        ItemStack drop = new ItemStack(st.getBlock().asItem());
        BlockEntity be = level.getBlockEntity(pos);
        if (be != null && !drop.isEmpty()) {
            CompoundTag data = be.saveWithoutMetadata(level.registryAccess());
            Identifier beId = BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(be.getType());
            if (beId != null) {
                data.putString("id", beId.toString());
                CompoundTag item = new CompoundTag();
                item.putString("id", BuiltInRegistries.ITEM.getKey(drop.getItem()).toString());
                item.putInt("count", 1);
                CompoundTag comps = new CompoundTag();
                comps.put("minecraft:block_entity_data", data);
                item.put("components", comps);
                Optional<ItemStack> parsed = ItemStack.CODEC.parse(RegistryOps.create(NbtOps.INSTANCE, level.registryAccess()), item).result();
                if (parsed.isPresent()) {
                    drop = parsed.get();
                }
            }
        }

        level.destroyBlock(pos, false, player);
        if (!drop.isEmpty()) {
            if (!player.getInventory().add(drop)) {
                player.drop(drop, false);
            }
        }

        CustomData.update(DataComponents.CUSTOM_DATA, tool, tag -> tag.putBoolean(USED_KEY, true));
        tool.set(DataComponents.LORE, new ItemLore(List.of(
                Component.translatable("item.megacraft.forbidden_pickaxe.lore_used")
                        .withStyle(Style.EMPTY.withItalic(false).withColor(ChatFormatting.DARK_GRAY)))));
        player.displayClientMessage(Component.translatable("message.megacraft.forbidden_done"), true);
        return true;
    }
}

package ru.megacraft;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.NestedLootTable;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

/** Во все ванильные сундуки структур добавляем «бонусный» пул (книги, редкие супер-предметы). */
public final class LootHooks {
    private static final ResourceKey<LootTable> BONUS =
            ResourceKey.create(Registries.LOOT_TABLE, MegacraftMod.id("chests/bonus"));

    private LootHooks() {
    }

    public static void init() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (!source.isBuiltin()) {
                return;
            }
            if (!key.toString().contains("minecraft:chests/")) {
                return;
            }
            tableBuilder.withPool(LootPool.lootPool()
                    .setRolls(ConstantValue.exactly(1.0F))
                    .add(NestedLootTable.lootTableReference(BONUS)));
        });
    }
}

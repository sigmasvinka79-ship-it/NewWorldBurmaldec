package ru.megacraft;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Рубка деревьев, бульдозер (3x3 / 5x5) и «Паутина» (жила руды). */
public final class BreakHooks {
    private static final int MAX_LOGS = 512;
    private static final int MAX_LEAVES = 900;
    private static final int MAX_VEIN = 96;

    private record FaceInfo(BlockPos pos, Direction face) {
    }

    private static final Map<UUID, FaceInfo> FACES = new HashMap<>();
    private static boolean busy = false;

    private BreakHooks() {
    }

    public static void init() {
        AttackBlockCallback.EVENT.register((player, level, hand, pos, direction) -> {
            if (level instanceof ServerLevel) {
                FACES.put(player.getUUID(), new FaceInfo(pos.immutable(), direction));
            }
            return InteractionResult.PASS;
        });
        PlayerBlockBreakEvents.AFTER.register(BreakHooks::onAfterBreak);
    }

    private static void onAfterBreak(Level level, Player player, BlockPos pos, BlockState state, BlockEntity be) {
        if (busy) {
            return;
        }
        if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) {
            return;
        }
        if (sp.isCreative() || sp.isSpectator()) {
            return;
        }
        ItemStack tool = sp.getMainHandItem();
        if (tool.isEmpty()) {
            return;
        }
        busy = true;
        try {
            ItemStack snapshot = tool.copy();
            int damage = 0;
            if (snapshot.is(ItemTags.AXES) && state.is(BlockTags.LOGS)) {
                damage += fellTree(sl, sp, pos, state, snapshot);
            } else {
                if (ModEnchants.level(snapshot, ModEnchants.VEIN) > 0 && state.is(MegaTags.VEIN_MINEABLE)) {
                    damage += mineVein(sl, sp, pos, state, snapshot);
                }
                int bulldozer = ModEnchants.level(snapshot, ModEnchants.BULLDOZER);
                if (bulldozer > 0) {
                    damage += drill(sl, sp, pos, snapshot, bulldozer);
                }
            }
            if (damage > 0) {
                ItemStack current = sp.getMainHandItem();
                if (!current.isEmpty()) {
                    current.hurtAndBreak(damage, sp, EquipmentSlot.MAINHAND);
                }
            }
        } finally {
            busy = false;
        }
    }

    private static void breakBlock(ServerLevel level, ServerPlayer player, BlockPos pos, ItemStack tool) {
        BlockState st = level.getBlockState(pos);
        if (st.isAir()) {
            return;
        }
        BlockEntity be = level.getBlockEntity(pos);
        Block.dropResources(st, level, pos, be, player, tool);
        level.destroyBlock(pos, false, player);
    }

    // ---------------------------------------------------------------- дерево

    private static boolean isTreeLeaf(BlockState s, int depth) {
        if (s.is(BlockTags.LEAVES)) {
            if (s.hasProperty(LeavesBlock.PERSISTENT) && s.getValue(LeavesBlock.PERSISTENT)) {
                return false;
            }
            if (s.hasProperty(LeavesBlock.DISTANCE) && s.getValue(LeavesBlock.DISTANCE) < depth) {
                return false;
            }
            return true;
        }
        return s.is(BlockTags.WART_BLOCKS);
    }

    private static int fellTree(ServerLevel level, ServerPlayer player, BlockPos origin, BlockState originState, ItemStack tool) {
        Block logBlock = originState.getBlock();
        Set<Long> seen = new HashSet<>();
        List<BlockPos> logs = new ArrayList<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(origin.asLong());
        queue.add(origin);
        while (!queue.isEmpty() && logs.size() < MAX_LOGS) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        BlockPos n = cur.offset(dx, dy, dz);
                        if (Math.abs(n.getX() - origin.getX()) > 12 || Math.abs(n.getZ() - origin.getZ()) > 12
                                || Math.abs(n.getY() - origin.getY()) > 48) {
                            continue;
                        }
                        if (!seen.add(n.asLong())) {
                            continue;
                        }
                        if (level.getBlockState(n).is(logBlock)) {
                            logs.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }

        List<BlockPos> leaves = new ArrayList<>();
        Map<Long, Integer> depth = new HashMap<>();
        ArrayDeque<BlockPos> lq = new ArrayDeque<>();
        depth.put(origin.asLong(), 0);
        lq.add(origin);
        for (BlockPos p : logs) {
            depth.put(p.asLong(), 0);
            lq.add(p);
        }
        while (!lq.isEmpty() && leaves.size() < MAX_LEAVES) {
            BlockPos cur = lq.poll();
            int d = depth.get(cur.asLong());
            if (d >= 6) {
                continue;
            }
            for (Direction dir : Direction.values()) {
                BlockPos n = cur.relative(dir);
                if (depth.containsKey(n.asLong())) {
                    continue;
                }
                BlockState ns = level.getBlockState(n);
                if (isTreeLeaf(ns, d + 1)) {
                    depth.put(n.asLong(), d + 1);
                    leaves.add(n);
                    lq.add(n);
                }
            }
        }

        // Нет листвы рядом - это постройка из брёвен, а не дерево: не трогаем.
        if (leaves.isEmpty()) {
            return 0;
        }
        for (BlockPos p : logs) {
            breakBlock(level, player, p, tool);
        }
        for (BlockPos p : leaves) {
            breakBlock(level, player, p, tool);
        }
        return Math.min(12, Math.max(1, logs.size() / 3));
    }

    // ---------------------------------------------------------------- жила

    private static int mineVein(ServerLevel level, ServerPlayer player, BlockPos origin, BlockState originState, ItemStack tool) {
        Block target = originState.getBlock();
        Set<Long> seen = new HashSet<>();
        List<BlockPos> found = new ArrayList<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(origin.asLong());
        queue.add(origin);
        while (!queue.isEmpty() && found.size() < MAX_VEIN) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        BlockPos n = cur.offset(dx, dy, dz);
                        if (Math.abs(n.getX() - origin.getX()) > 10 || Math.abs(n.getY() - origin.getY()) > 10
                                || Math.abs(n.getZ() - origin.getZ()) > 10) {
                            continue;
                        }
                        if (!seen.add(n.asLong())) {
                            continue;
                        }
                        if (level.getBlockState(n).is(target)) {
                            found.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }
        for (BlockPos p : found) {
            breakBlock(level, player, p, tool);
        }
        return found.isEmpty() ? 0 : Math.max(1, found.size() / 2);
    }

    // ---------------------------------------------------------------- бульдозер

    private static Direction faceFor(ServerPlayer player, BlockPos origin) {
        FaceInfo fi = FACES.get(player.getUUID());
        if (fi != null && fi.pos().equals(origin)) {
            return fi.face();
        }
        Vec3 look = player.getLookAngle();
        return Direction.getApproximateNearest(look.x, look.y, look.z);
    }

    private static int drill(ServerLevel level, ServerPlayer player, BlockPos origin, ItemStack tool, int lvl) {
        int r = lvl >= 2 ? 2 : 1; // I = 3x3, II = 5x5
        Direction face = faceFor(player, origin);
        Direction.Axis axis = face.getAxis();
        int broken = 0;
        for (int a = -r; a <= r; a++) {
            for (int b = -r; b <= r; b++) {
                if (a == 0 && b == 0) {
                    continue;
                }
                BlockPos p = switch (axis) {
                    case X -> origin.offset(0, a, b);
                    case Y -> origin.offset(a, 0, b);
                    case Z -> origin.offset(a, b, 0);
                };
                BlockState st = level.getBlockState(p);
                if (st.isAir() || st.getBlock() instanceof LiquidBlock || st.hasBlockEntity()) {
                    continue;
                }
                if (st.getDestroySpeed(level, p) < 0) {
                    continue;
                }
                if (st.requiresCorrectToolForDrops() && !tool.isCorrectToolForDrops(st)) {
                    continue;
                }
                breakBlock(level, player, p, tool);
                broken++;
            }
        }
        return broken == 0 ? 0 : Math.max(1, broken / 3);
    }
}
